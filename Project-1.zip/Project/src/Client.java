import java.io.*;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import java.util.zip.Adler32;
import java.util.zip.Checksum;

public class Client {
//    private String dir = "C:\\Users\\SIU856533724\\OneDrive - Southern Illinois University\\Desktop\\ProDistributed Application\\Project\\Source\\";
    private static long totalByte = 0;
//    private static int conCurr = 0;
    static int totalFiles = 0;
   static ClientUI clientUI = new ClientUI();

    public Client() {
//        this.dir = dir;
//        this.conCurr = concurr;
    }
//    createParallelConnection(conCurr);
//    public static void main(String[] args) throws IOException {
////        Scanner scanner = new Scanner(System.in);
////        System.out.print("Input Number of conCurr: ");
////        int conCurr = scanner.nextInt();
//        createParallelConnection(conCurr);
//    }

    public static void createParallelConnection(String dir, int conCurr) throws IOException, ClassNotFoundException, SQLException {
        System.out.printf("Dir: "+dir);
        System.out.printf("ConCur: "+conCurr);
        File[] files = new File(dir).listFiles();
        totalFiles = files.length;
        Queue<File> fileQueue = new LinkedList<>();
        Queue<Thread> threadQueue = new LinkedList<>();
        List<List<File>> fileListOfList = new ArrayList<>();

        Socket socket;
        DataOutputStream dos;
        BufferedOutputStream bos;

        for (File file : files) {
            fileQueue.add(file);
        }

        while (true) {
            List<File> fileList = getFileList(fileQueue, conCurr);
            fileListOfList.add(fileList);
            if (fileList.size() == 0) {
                break;
            }
        }

        // Time storing to startTime as millisecond
        // later we convert it to second
        long startTime = (long) System.currentTimeMillis();
        for(List<File> fileList: fileListOfList) {

            for (File file : fileList) {
                try {
                    socket = new Socket("localhost",5050);
                    dos = new DataOutputStream(socket.getOutputStream());
                    bos = new BufferedOutputStream(dos);

                    totalByte += file.length(); //total byte calculating

                    Thread t = new Thread(new SendSingleFileHandler(socket, dos, bos, file));
                    t.start();
                    threadQueue.add(t);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            checkThread(fileQueue, threadQueue);
        }
        long totalTime = (long) (System.currentTimeMillis() - startTime);
        Double cost = totalTime/1000.0; // convert to second
        System.out.println("Total time: "+cost +" sec");
        clientUI.display("Total time: "+cost +" sec", totalFiles);
        System.out.println("Total Data: "+ totalByte +" bytes");
        clientUI.display("Total Data: "+ totalByte +" bytes", totalFiles);
        Double throughput = totalByte/(totalTime*1024.0);
        System.out.println("Throughput: "+throughput+" KBps");
        clientUI.display("Throughput: "+throughput+" KBps", totalFiles);

        // JDBC driver name and database URL
        String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
        String DB_URL = "jdbc:mysql://localhost:3306/pda_project";

        // Database credentials
        String USER = "root";
        String PASS = "root!";

        Connection conn = null;
        Statement stmt = null;

        //Register JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        //Open a connection
        System.out.println("Connecting to a selected database...");
        conn = DriverManager.getConnection(DB_URL, USER, PASS);
        System.out.println("Connected database successfully...");

        //Execute a query
        System.out.println("Creating statement...");

        stmt = conn.createStatement();
        String concurrency = conCurr+"";
//        String thput = Math.round(throughput) + "";
        String thput = String.format("%.2f", throughput);
        String sql = "INSERT INTO output (concurrency, throughput) VALUES ("+concurrency+", "+thput+")";
        stmt.executeUpdate(sql);
    }

    public static int getFileCount() {
        return  totalFiles;
    }

    private static List<File> getFileList(Queue<File> Q, int conCurr) {
        List<File> list = new ArrayList<>();

        while (!Q.isEmpty() && conCurr >= 1) {
            list.add(Q.remove());
            conCurr--;
        }
        return list;
    }

    private static void checkThread(Queue<File> fileQueue, Queue<Thread> threadQueue) {
        DataOutputStream dos;
        BufferedOutputStream bos;
        Socket socket;

        while (!threadQueue.isEmpty()) {
            try {
                Thread t = threadQueue.remove();
                if(!t.isAlive() && !fileQueue.isEmpty()) {
                    socket = new Socket("localhost",5050);
                    dos = new DataOutputStream(socket.getOutputStream());
                    bos = new BufferedOutputStream(dos);

                    File file = fileQueue.remove();
                    totalByte += file.length();

                    t = new Thread(new SendSingleFileHandler(socket, dos, bos, file));
                    t.start();
                }
                t.join();
            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class SendSingleFileHandler implements Runnable {
        final Socket sock;
        final DataOutputStream dos;
        final BufferedOutputStream bos;
        final File file;

        static ClientUI clientUI = new ClientUI();
        static Client client = new Client();

        SendSingleFileHandler(Socket socket, DataOutputStream dos,
                              BufferedOutputStream bos,
                              File file) throws IOException {
            this.sock=socket;
            this.dos = dos;
            this.bos = bos;
            this.file = file;
        }

        @Override
        public void run() {
            try {
                String name = file.getName();
                dos.writeUTF(name);

                FileInputStream fis = new FileInputStream(file);
                BufferedInputStream bis = new BufferedInputStream(fis);
                byte[] bt = bis.readAllBytes();
                dos.write(bt);

                Checksum checksum = new Adler32();
                checksum.update(bt,0,bt.length);
                System.out.println("Checksum: "+checksum.getValue());
//                ClientUI clientUI = new ClientUI();
                int totalFiles = client.getFileCount();
                clientUI.display("Checksum: "+ String.valueOf(checksum.getValue()), totalFiles);

                bis.close();
                bos.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
}
