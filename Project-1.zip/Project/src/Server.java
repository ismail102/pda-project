
/******************************************************************************
 *  Compilation:  javac GUI.java
 *  Execution:    java GUI
 *
 *  A minimal Java program with a graphical user interface. The
 *  GUI prints out the number of times the user clicks a button.
 *
 *  % java GUI
 *
 ******************************************************************************/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.zip.Adler32;
import java.util.zip.Checksum;

public class Server implements ActionListener {

    Connection connection = null; // manages connection
    Statement statement = null; // query statement
    ResultSet resultSet = null; // manages results
    private static int clicks = 0;
    private static JLabel clickLabel = new JLabel("Number of file received:  0");
    private static JFrame frame = new JFrame();
    static JProgressBar jb;

    // the clickable button
    static JButton button = new JButton("Click Me");
    static JButton button2 = new JButton("Click Me");
    static JTextArea displayArea = new JTextArea("");
    int i = 0, num = 0;

    public Server() {

        JButton showData = new JButton("Show Data");
        JButton showGraph = new JButton("Generate Graph");
//        add(showData, BorderLayout.CENTER);

        // create event listener for show data button
        showData.addActionListener(
                new ActionListener()
                {
                    public void actionPerformed( ActionEvent event )
                    {
                        // perform a new query
                        try
                        {
                            new DisplayThroughput();
                        } // end try
                        catch ( Exception e )
                        {
                            e.printStackTrace();
                        }
                    }
                }
        ); // end call to addActionListener

        // create event listener for show data button
        showGraph.addActionListener(
                new ActionListener()
                {
                    public void actionPerformed( ActionEvent event )
                    {
                        // perform a new query
                        try
                        {
                            GraphPlot graphPlot = new GraphPlot();
                            graphPlot.createAndShowGui();
                        } // end try
                        catch ( Exception e )
                        {
                            e.printStackTrace();
                        }
                    }
                }
        ); // end call to addActionListener


        // JLabel label1 = new JLabel("Connecting");
        jb = new JProgressBar(0, 100);
//        button.addActionListener(this);
        // jb.setBounds(40, 40, 160, 100);
        jb.setValue(0);
        jb.setStringPainted(true);
        // the panel with the button and text
        JPanel panel = new JPanel();
        panel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));
        panel.setLayout(new GridLayout(2, 1));
        displayArea.setEditable(false);
        panel.add(new JScrollPane(displayArea));
        // panel.add(button2);
        panel.add(clickLabel);

        // set up the frame and display it
        // frame.add(label1, BorderLayout.PAGE_START);
        frame.add(panel, BorderLayout.CENTER);
//        frame.add(jb, BorderLayout.PAGE_START);
//        frame.add(button, BorderLayout.PAGE_END);
        frame.add(showData, BorderLayout.PAGE_START);
        frame.add(showGraph, BorderLayout.PAGE_END);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setTitle("Server");
        frame.pack();
        frame.setSize(500, 400);
        frame.setVisible(true);
    }

    // process the button clicks
    public void actionPerformed(ActionEvent e) {
        clicks++;
        i = i + 1;
        jb.setValue(i);
//        clickLabel.setText(String.valueOf(i));
    }

    public void displayServer(String str)
    {
//        clicks++;
        i = i + 1;
//        jb.setValue(i);

        clickLabel.setText("Number of file received: "+String.valueOf(i));

        SwingUtilities.invokeLater(
                new Runnable()
                {
                    public void run()
                    {
                        displayArea.append( str ); // updates output
                        displayArea.append("\n");
                    } // end method run
                }  // end inner class
        ); // end call to SwingUtilities.invokeLater
    }

    private static void receiveFile(Socket socket) throws IOException {
        try {
            DataInputStream dis = new DataInputStream(socket.getInputStream());
            BufferedInputStream bis = new BufferedInputStream(dis);
            Thread t = new Thread(new ClientHandler(socket, dis, bis));
            t.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // create one Frame
    public static void main(String[] args) throws IOException {
        new Server();

        ServerSocket servsock = new ServerSocket(5050);
        Socket socket = null;

        // running infinite loop for getting
        // client request
        while (true) {
            try {
                socket = servsock.accept();
                receiveFile(socket);
            } catch (Exception e) {
                System.out.println(e);
            }
        }

    }
}

class ClientHandler extends Thread {
    final String dir = "C:\\Users\\SIU856533724\\OneDrive - Southern Illinois University\\Desktop\\ProDistributed Application\\Project\\Destination\\"; // you
                                                                                                                  // may// change// this
    final DataInputStream dis;
    final BufferedInputStream bis;
    final Socket socket;
    static Server server = new Server();

    public ClientHandler(Socket socket, DataInputStream dis, BufferedInputStream bis) {
        this.socket = socket;
        this.dis = dis;
        this.bis = bis;
    }

    @Override
    public void run() {
        try {
            String name = dis.readUTF();

            FileOutputStream fos = new FileOutputStream(new File(dir + name));
            BufferedOutputStream bos = new BufferedOutputStream(fos);

            byte[] bt = dis.readAllBytes();
            bos.write(bt);

            Checksum checksum = new Adler32();
            checksum.update(bt, 0, bt.length);
            System.out.println("Checksum: " + checksum.getValue());

//            clicks++;
//            i = i + 20;
//            jb.setValue(i);
//
            server.displayServer("Checksum: " + checksum.getValue());

            bos.close();
            bis.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}