// Fig. 25.31: DisplayQueryResults.java
// Display the contents of the Authors table in the
// Books database.

import javax.swing.*;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.SQLException;
import java.util.regex.PatternSyntaxException;

public class DisplayThroughput extends JFrame
{
   // JDBC driver, database URL, username and password
   static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
   static final String DATABASE_URL = "jdbc:mysql://localhost:3306/pda_project";
   static final String USERNAME= "root";
   static final String PASSWORD= "root!";

   // default query retrieves all data from authors table
   static final String DEFAULT_QUERY = "SELECT * FROM output";

   private ResultSetTableModel tableModel;

   private JTextArea queryArea;

   // create ResultSetTableModel and GUI
   public DisplayThroughput()
   {   
      super( "Displaying Throughput" );
        
      // create ResultSetTableModel and display database table
      try 
      {
         // create TableModel for results of query SELECT * FROM authors
         tableModel = new ResultSetTableModel( JDBC_DRIVER, DATABASE_URL, 
            USERNAME, PASSWORD, DEFAULT_QUERY );

         // set up JTextArea in which user types queries
         queryArea = new JTextArea( DEFAULT_QUERY, 3, 100 );
         queryArea.setWrapStyleWord( true );
         queryArea.setLineWrap( true );
         
         JScrollPane scrollPane = new JScrollPane( queryArea,
            ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, 
            ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER );

         JButton exitButton = new JButton( "Exit" );

         // create Box to manage placement of queryArea and 
         // submitButton in GUI
         Box boxNorth = Box.createHorizontalBox();
         boxNorth.add( scrollPane );
         boxNorth.add( exitButton );

         // create JTable delegate for tableModel 
         JTable resultTable = new JTable( tableModel );
         
         // place GUI components on content pane
         add( boxNorth, BorderLayout.NORTH );
         add( new JScrollPane( resultTable ), BorderLayout.CENTER );

       // create event listener for exitButton
         exitButton.addActionListener(
            new ActionListener() 
            {
               // pass query to table model
               public void actionPerformed( ActionEvent event )
               {
               System.exit( 1 ); // terminate application
                }
              }
            );

	 final TableRowSorter <TableModel > sorter = 
                             new TableRowSorter <TableModel> (tableModel);
	 resultTable.setRowSorter(sorter);
         setSize( 500, 250 ); // set window size
         setVisible( true ); // display window
       } // end try
      catch ( ClassNotFoundException classNotFound ) 
      {
         JOptionPane.showMessageDialog( null, 
            "MySQL driver not found", "Driver not found",
            JOptionPane.ERROR_MESSAGE );
         
         System.exit( 1 ); // terminate application
      } // end catch
      catch ( SQLException sqlException ) 
      {
         JOptionPane.showMessageDialog( null, sqlException.getMessage(), 
            "Database error", JOptionPane.ERROR_MESSAGE );
               
         // ensure database connection is closed
         tableModel.disconnectFromDatabase();
         
         System.exit( 1 );   // terminate application
      } // end catch
      
      // dispose of window when user quits application (this overrides
      // the default of HIDE_ON_CLOSE)
      setDefaultCloseOperation( DISPOSE_ON_CLOSE );
      
      // ensure database connection is closed when user quits application
      addWindowListener(
      
         new WindowAdapter() 
         {
            // disconnect from database and exit when window has closed
            public void windowClosed( WindowEvent event )
            {
               tableModel.disconnectFromDatabase();
               System.exit( 0 );
            } // end method windowClosed
         } // end WindowAdapter inner class
      ); // end call to addWindowListener
   } // end DisplayQueryResults constructor
} // end class DisplayQueryResults



/**************************************************************************
 * (C) Copyright 1992-2005 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/