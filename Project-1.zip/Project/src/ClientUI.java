// Java program to create open or
// save dialog using JFileChooser
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.sql.SQLException;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.*;
class ClientUI extends JFrame implements ActionListener {

    static int i = 0, num = 0;
    static int totalFiles = 0;
    static JProgressBar jb;

    // Jlabel to show the files user selects
    static JLabel l;
    static JTextField textField = new JTextField("", 16);

    static JLabel jLabel1 = new JLabel("Enter Concurrent Number");
    static JLabel jLabel2 = new JLabel("No concurrency number entered");
    static JLabel jLabel3 = new JLabel("Source Directory not selected");

    static JTextArea textarea = new JTextArea ("");

    // button to open save dialog
    static JButton button1 = new JButton("SEND");

    // button to open open dialog
    static JButton button2 = new JButton("SELECT");
    static JTextArea displayArea = new JTextArea(16, 58);
    static JScrollPane scroll;
    StringBuilder sb = new StringBuilder("");
    // a default constructor
    public ClientUI()
    {
    }
    public static void main(String args[])
    {

        jb = new JProgressBar(0, 100);
//        button.addActionListener(this);
        // jb.setBounds(40, 40, 160, 100);
        jb.setValue(0);
        jb.setStringPainted(true);

        // frame to contains GUI elements
        JFrame f = new JFrame("Client");

        // set the size of the frame
        f.setSize(600, 600);

        // set the frame's visibility
        f.setVisible(true);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // make an object of the class filechooser
        ClientUI f1 = new ClientUI();

        // add action listener to the button to capture user
        // response on buttons
        button1.addActionListener(f1);
        button2.addActionListener(f1);

        // make a panel to add the buttons and labels
        JPanel p = new JPanel();

        // add buttons to the frame
//        p.add(button1);
//        p.add(button2);
//        p.add(textField);
//        p.add(jLabel1);

        displayArea.setEditable(false); // set textArea non-editable
//        scroll = new JScrollPane(displayArea);
//        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

        // set the label to its initial value
        l = new JLabel("no file selected");

        // add panel to the frame
//        p.add(l);

//        f.add(p);

        f.add(new TestPane(button1, button2, textField, jLabel1,jLabel2,jLabel3, textarea, displayArea, jb));
        f.pack();
        f.setLocationRelativeTo(null);
        f.setVisible(true);

        f.show();
    }
    public void actionPerformed(ActionEvent evt)
    {
        // if the user presses the SEND button show the SEND dialog
        String com = evt.getActionCommand();

        if (com.equals("SELECT")) {
            // create an object of JFileChooser class
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

            // invoke the showsSaveDialog function to show the SEND dialog
            int r = fileChooser.showOpenDialog(null);

            // if the user selects a file
            if (r == JFileChooser.APPROVE_OPTION) {
                // set the label to the path of the selected file
                jLabel3.setVisible(false);
                jLabel3.setText(fileChooser.getSelectedFile().getAbsolutePath());

                textarea.setVisible(true);
                textarea.setLineWrap(true);
                textarea.setWrapStyleWord(true);
                String dir = fileChooser.getSelectedFile().getAbsolutePath();
                textarea.setText(dir);
            }
            // if the user cancelled the operation
            else
                jLabel3.setText("the user cancelled the operation");
        } else if(com.equals("SEND")) {
            // set the text of the label to the text of the field
//            jLabel1.setText("Concurrent Number is: "+textField.getText());
            // set the text of field to blank
            Client client = new Client();
            try {
//                button2.disable();
//                button1.disable();
//                button1.setText("Sending...");
                client.createParallelConnection(jLabel3.getText(), Integer.valueOf(textField.getText()));
//                textField.setText("  ");
            } catch (IOException e) {
                throw new RuntimeException(e);
            } catch (SQLException e) {
                throw new RuntimeException(e);
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }

        // if the user presses the open dialog show the open dialog
        else {

        }
    }

    public void display(String str, int totalFiles)
    {
//       clicks++;
        i = i + 1;
        int p = (i/totalFiles)*100;
        jb.setValue(p);

        button1.disable();
        button2.disable();
        System.out.println("Count: "+ i);
        System.out.println("Total files: "+ totalFiles);
        if(i >= totalFiles) {
            button1.setText("Sent");
        } else {
            button1.setText("Sending...");
        }

        SwingUtilities.invokeLater(
                new Runnable()
                {
                    public void run()
                    {
                        displayArea.append( str ); // updates output
                        displayArea.append("\n");
                    } // end method run
                }  // end inner class
        ); // end call to SwingUtilities.invokeLater
//        scroll = new JScrollPane(display);
//        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);

//        System.out.println(sum);
        System.out.printf("HELLO From Client!!");
    }
}
class TestPane extends JPanel {

    public TestPane(JButton button1, JButton button2, JTextField textField,
                    JLabel jLabel1, JLabel jLabel2, JLabel jLabel3, JTextArea textarea,
                    JTextArea displayArea, JProgressBar jb) {
        setBorder(new EmptyBorder(100, 100, 100, 100));
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        textarea.setVisible(false);

        add(jb, gbc);
        add(jLabel1, gbc);
        add(textField, gbc);
//        add(jLabel2, gbc);
        add(button2, gbc);
        add(jLabel3, gbc);
        add(textarea, gbc);
        add(button1, gbc);
        add(new JScrollPane( displayArea ), gbc);
//        add(scroll, gbc);

    }

}
